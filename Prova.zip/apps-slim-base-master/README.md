# Aplicação Exemplo Técnico SENAI

Para rodar a aplicação execute:  
    php -S localhost:8888 -t public public/index.php