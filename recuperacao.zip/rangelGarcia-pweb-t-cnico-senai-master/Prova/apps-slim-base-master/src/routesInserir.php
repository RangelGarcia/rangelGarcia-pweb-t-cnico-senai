<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    $app->get('/inserir_registro/[{sucesso}]', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/carro/' route");

        // Render index view
        return $container->get('renderer')->render($response, 'inserir.phtml', $args);
    });

    $app->post('/inserir_registro/', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/inserir_registro/' route");

        $conexao = $container->get('pdo');

        $params = $request->getParsedBody();

        $modelo = $_POST['modelo'];
        $marca = $_POST['marca'];
        $ano = $_POST['ano'];
        

        $resultSet = $conexao->query ("INSERT INTO carro (modelo, marca, ano) 
                                    VALUES ('$modelo', 
                                            '$marca', 
                                            '$ano' 
                                            )");
                                            
        return $response->withRedirect('/carro/');
    });
};
