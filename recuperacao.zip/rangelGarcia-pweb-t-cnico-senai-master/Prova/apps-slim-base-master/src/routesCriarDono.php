<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    $app->get('/criar_dono/[{sucesso}]', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/carro/' route");

        $conexao = $container->get('pdo');
        
        $resultSet = $conexao->query('SELECT * FROM carro')->fetchAll();

        $args['carros'] = $resultSet;

        // Render index view
        return $container->get('renderer')->render($response, 'criarDono.phtml', $args);
    });

    $app->post('/criar_dono/', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/inserir_registro/' route");

        $conexao = $container->get('pdo');

        $params = $request->getParsedBody();

        $nome = $_POST['nome'];
        $id = $_POST['id'];
        
        

        $resultSet = $conexao->query ("INSERT INTO dono (nome, id) 
                                    VALUES ('$nome', 
                                            '$id'                                             
                                            )");
                                            
        return $response->withRedirect('/dono/');
    });
};
